
/* Includes ------------------------------------------------------------------*/
#include <intrinsics.h>
#include "stm32f10x_lib.h"

volatile unsigned int LedState = 0; // LED is ON when corresponding bit is 1.

void LEDsSet(unsigned int State, unsigned int GPIO_Pin_XX);

/*******************************************************************************
 * Function Name: Timer1IntrHandler
 * Parameters:    none
 *
 * Return:        none
 *
 * Description:   Timer 1 interrupt handler
 *
 *******************************************************************************/
void Timer1IntrHandler(void)
{
  // Clear update interrupt bit.
  TIM1_ClearITPendingBit(TIM1_FLAG_Update);
  
    if(LedState == 0)
    {
      LedState = 1;
      LEDsSet(LedState,GPIO_Pin_5);
    }
    else
    {
      LedState = 0;
      LEDsSet(LedState,GPIO_Pin_5);  
    }
  
  SerialPutString("\r\n Test interrupt OK!");
  
  //LEDsSet(1,GPIO_Pin_4);
  //LEDsSet(1,GPIO_Pin_5);
  //LEDsSet(1,GPIO_Pin_6);
}
/*******************************************************************************
 * Function Name: Clk_Init
 * Parameters:    Int32U Frequency
 * Return:        Int32U
 *
 * Description:   Init clock system
 *
 *******************************************************************************/
void Clk_Init(void)
{
  // Clocking the controller from internal HSI RC (8 MHz).
  RCC_HSICmd(ENABLE);
  // Wait until the HSI is ready.
  while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET);
  RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);
  // Enable ext. high frequency OSC.
  RCC_HSEConfig(RCC_HSE_ON);
  // Wait until the HSE is ready.
  while(RCC_GetFlagStatus(RCC_FLAG_HSERDY) == RESET);
  // Init PLL.
  RCC_PLLConfig(RCC_PLLSource_HSE_Div1,RCC_PLLMul_9);
  // 72MHz.
  RCC_PLLCmd(ENABLE);
  // Wait until the PLL is ready.
  while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
  // Set system clock dividers.
  RCC_USBCLKConfig(RCC_USBCLKSource_PLLCLK_1Div5);
  RCC_ADCCLKConfig(RCC_PCLK2_Div8);
  RCC_PCLK2Config(RCC_HCLK_Div1);
  RCC_PCLK1Config(RCC_HCLK_Div2);
  RCC_HCLKConfig(RCC_SYSCLK_Div1);
#ifdef EMB_FLASH
  // Init Embedded Flash.
  // Zero wait state, if 0 < HCLK 24 MHz.
  // One wait state, if 24 MHz < HCLK 56 MHz.
  // Two wait states, if 56 MHz < HCLK 72 MHz.
  // Flash wait state.
  FLASH_SetLatency(FLASH_Latency_2);
  // Half cycle access.
  FLASH_HalfCycleAccessCmd(FLASH_HalfCycleAccess_Disable);
  // Prefetch buffer.
  FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
#endif // EMB_FLASH.
  // Clock system from PLL.
  RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
}
/*******************************************************************************
 * Function Name: LEDsSet
 * Parameters:    unsigned int State
 *
 * Return:        none
 *
 * Description:   Set LEDS State
 *
 *******************************************************************************/
void LEDsSet(unsigned int State, unsigned int GPIO_Pin_XX)
{
   GPIO_WriteBit(GPIOA,GPIO_Pin_XX,State?Bit_SET:Bit_RESET);
}
/*******************************************************************************
 * Function Name: main
 * Parameters:    none
 *
 * Return:        none
 *
 * Description:   main
 *
 *******************************************************************************/
void main(void)
{
NVIC_InitTypeDef NVIC_InitStructure;
GPIO_InitTypeDef GPIO_InitStructure;
USART_InitTypeDef USART_InitStructure;
TIM1_TimeBaseInitTypeDef TIM1_TimeBaseInitStruct;

#ifdef DEBUG
  debug();
#endif

  //***
  NVIC_SETPRIMASK();
  //***

  // Init clock system.
  Clk_Init();

  // NVIC init.
#ifndef  EMB_FLASH
  /* Set the Vector Table base location at 0x20000000 */
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);
#else  /* VECT_TAB_FLASH  */
  /* Set the Vector Table base location at 0x08000000 */
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);
#endif
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
  
  // GPIO Init.
  // Enable GPIO clock and release reset.
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);
  RCC_APB2PeriphResetCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, DISABLE);

  // Assign PC0->PC13 to LED 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;  
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  LEDsSet(1,GPIO_Pin_4);
  LEDsSet(1,GPIO_Pin_5);
  LEDsSet(1,GPIO_Pin_6);
  
  //while(1);
  
  // USART Init.
  // Enable USART1 clock and release reset.
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1,ENABLE);
  RCC_APB2PeriphResetCmd(RCC_APB2Periph_USART1,DISABLE);
  
  /* Configure the GPIO ports( USART1 Transmit and Receive Lines) */
  /* Configure the USART1_Tx as Alternate function Push-Pull */
  GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  /* Configure the USART1_Rx as input floating */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 ;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
/* USART1 configuration ------------------------------------------------------*/
/* USART1 configured as follow:
        - BaudRate = 115200 baud  
        - Word Length = 8 Bits
        - One Stop Bit
        - No parity
        - Hardware flow control disabled (RTS and CTS signals)
        - Receive and transmit enabled
*/
  USART_InitStructure.USART_BaudRate = 115200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

  /* Configure the USART1 */
  USART_Init(USART1, &USART_InitStructure);

  /* Enable the USART1 */
  USART_Cmd(USART1, ENABLE);
  
  // Gooo !!!
  SerialPutString("\r\n======================================================================");
  SerialPutString("\r\n=                      (C) TERRAELECTRONICA                          =");
  SerialPutString("\r\n=     In-Application Programming Application  (Version 1.0.0)        =");
  SerialPutString("\r\n======================================================================");
  SerialPutString("\r\n");
  SerialPutString("System test:");
  
  //while(1);
  
  // Timer1 Init.
  // Enable Timer1 clock and release reset.
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);
  RCC_APB2PeriphResetCmd(RCC_APB2Periph_TIM1,DISABLE);

  // Set timer period 0.5 sec.
  TIM1_TimeBaseInitStruct.TIM1_Prescaler = 720; // 10 us resolution.
  TIM1_TimeBaseInitStruct.TIM1_CounterMode = TIM1_CounterMode_Up;
  TIM1_TimeBaseInitStruct.TIM1_Period = 50000; // 500 ms.
  TIM1_TimeBaseInitStruct.TIM1_ClockDivision = TIM1_CKD_DIV1;
  TIM1_TimeBaseInitStruct.TIM1_RepetitionCounter = 0;
  TIM1_TimeBaseInit(&TIM1_TimeBaseInitStruct);

  // Clear update interrupt bit.
  TIM1_ClearITPendingBit(TIM1_FLAG_Update);
  // Enable update interrupt.
  TIM1_ITConfig(TIM1_FLAG_Update,ENABLE);

  NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQChannel;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 7;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  // Enable timer counting.
  TIM1_Cmd(ENABLE);

  //***
  NVIC_RESETPRIMASK();
  //***
  
  while(1);
}
#ifdef DEBUG
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* Infinite loop */
  while(1);
}
#endif
